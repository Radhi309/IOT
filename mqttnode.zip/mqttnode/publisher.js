var mqtt = require("mqtt");
var client = mqtt.connect("mqtt://localhost:1234");

const TOPIC = "MY_TOPIC"

const message = "Hello there I am sending the message";

client.on("connect",()=>{
    setInterval(()=>{
        client.publish(TOPIC,message);
        console.log(`Message Received ${message}`)
    },3000);
});