var mqtt = require("mqtt");
var client = mqtt.connect("mqtt://localhost:1234");

var TOPIC = "MY_TOPIC"

//client connect with broker then it will subscribe
client.on("connect",()=>{
    client.subscribe(TOPIC);
});

//Sending the message
client.on("message",(topic,message)=>{
    message = message.toString();
    console.log(`Message sent : ${message}`);
});
